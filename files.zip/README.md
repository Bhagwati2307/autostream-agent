# 🎬 AutoStream AI Sales Agent

> A conversational AI agent that converts social media conversations into qualified leads — built for the **ServiceHive / Inflx** ML Intern assignment.

---

## Table of Contents

1. [Project Overview](#project-overview)
2. [Architecture](#architecture)
3. [How to Run Locally](#how-to-run-locally)
4. [Conversation Flow](#conversation-flow)
5. [WhatsApp Deployment](#whatsapp-deployment-via-webhooks)
6. [File Structure](#file-structure)

---

## Project Overview

AutoStream is a fictional SaaS platform offering automated video-editing tools for content creators. This agent:

- **Classifies user intent** (greeting / inquiry / high-intent)
- **Answers questions via RAG** using a local JSON knowledge base
- **Collects lead information** (name, email, creator platform) when high intent is detected
- **Captures the lead** by calling `mock_lead_capture()` only after all three fields are collected
- **Maintains multi-turn memory** across the entire conversation using LangGraph state

---

## Architecture

### Why LangGraph?

LangGraph was chosen over AutoGen for this project for three key reasons:

1. **Explicit state machine control** — LangGraph models the agent as a directed graph of nodes and edges. Each step (intent classification → RAG retrieval → reply generation → lead collection → tool call) is a distinct, testable node. This makes the flow transparent and easy to debug, unlike AutoGen's actor model where control flow is implicit.

2. **Persistent typed state** — LangGraph's `TypedDict`-based `AgentState` holds the full conversation history, current intent, retrieved context, and all lead fields in one place. This state is threaded through every node automatically, making 5–6 turn memory trivial to implement without external memory stores.

3. **Conditional routing** — The `add_conditional_edges` API lets us express business logic like "only call the lead capture tool once all three fields are collected" as clean routing functions, preventing premature tool calls.

### How State is Managed

```
User Message
     │
     ▼
classify_intent  ──► intent: "greeting" | "inquiry" | "high_intent"
     │
     ├─ greeting/unknown ──► generate_reply ──► END
     │
     └─ inquiry/high_intent ──► retrieve_rag (RAG from local JSON KB)
                                     │
                                     ├─ inquiry ──► generate_reply ──► END
                                     │
                                     └─ high_intent ──► collect_lead
                                                              │
                                                              ├─ fields missing ──► END (await next turn)
                                                              │
                                                              └─ all fields present ──► capture_lead ──► END
```

The `AgentState` TypedDict accumulates:
- `messages` — full conversation history (reduces hallucination, enables context-aware replies)
- `intent` — classified for each user turn
- `retrieved_context` — RAG result, passed to the LLM system prompt
- `lead_name`, `lead_email`, `lead_platform` — incrementally filled across turns
- `lead_captured` — boolean flag to prevent double-capture

---

## How to Run Locally

### Prerequisites

- Python 3.9+
- An [Anthropic API key](https://console.anthropic.com/)

### Installation

```bash
# 1. Clone the repository
git clone https://github.com/your-username/autostream-agent.git
cd autostream-agent

# 2. Create and activate a virtual environment (recommended)
python -m venv venv
source venv/bin/activate        # macOS/Linux
# venv\Scripts\activate         # Windows

# 3. Install dependencies
pip install -r requirements.txt

# 4. Set your API key
export ANTHROPIC_API_KEY="sk-ant-..."   # macOS/Linux
# set ANTHROPIC_API_KEY=sk-ant-...      # Windows CMD
```

### Run the Agent

```bash
python main.py
```

### Example Session

```
You: Hi there!
AutoStream: Hey! Welcome to AutoStream 🎬 I'm here to help you learn about our
            video editing tools. What can I help you with today?

You: What are your pricing plans?
AutoStream: Great question! AutoStream offers two plans:
            • Basic – $29/month: 10 videos/month, 720p export, standard templates
            • Pro – $79/month: Unlimited videos, 4K export, AI captions, 24/7 support
            Which sounds like a better fit for you?

You: The Pro plan sounds perfect. I want to sign up for my YouTube channel.
AutoStream: Awesome! I'd love to get you set up. Could you share your **full name**?

You: Alex Johnson
AutoStream: Thanks, Alex! What's the best **email address** to reach you?

You: alex@example.com
AutoStream: Almost there! Which creator platform do you primarily use?

You: YouTube
AutoStream: ✅ Lead captured successfully!
            • Name:     Alex Johnson
            • Email:    alex@example.com
            • Platform: YouTube
            Our team will reach out within 24 hours!
```

---

## WhatsApp Deployment via Webhooks

To deploy this agent on WhatsApp, we use the **WhatsApp Business API (Cloud API)** with webhooks:

### Architecture

```
WhatsApp User
      │  (sends message)
      ▼
Meta Cloud API
      │  (HTTP POST webhook event)
      ▼
Your Server (FastAPI / Flask)
  ├── Verify webhook signature (X-Hub-Signature-256)
  ├── Parse incoming message payload
  ├── Call agent.chat(user_message, session_id)  ← per-user state
  └── POST reply to https://graph.facebook.com/v18.0/{phone_number_id}/messages
```

### Implementation Steps

1. **Register a WhatsApp Business Account** on [Meta for Developers](https://developers.facebook.com/).

2. **Set up a webhook endpoint** in your FastAPI app:

```python
from fastapi import FastAPI, Request
from agent import chat  # your LangGraph agent

app = FastAPI()
sessions = {}   # {whatsapp_number: AgentState}

@app.post("/webhook")
async def whatsapp_webhook(request: Request):
    body = await request.json()
    msg  = body["entry"][0]["changes"][0]["value"]["messages"][0]
    from_number = msg["from"]
    user_text   = msg["text"]["body"]

    # Per-user state (swap dict for Redis in production)
    reply = chat(user_text, session_id=from_number)

    # Send reply back via Meta Graph API
    send_whatsapp_message(to=from_number, text=reply)
    return {"status": "ok"}
```

3. **Verify the webhook** with the `VERIFY_TOKEN` during Meta's handshake (GET request).

4. **Use Redis or a database** to store per-user `AgentState` in production, replacing the in-memory `sessions` dict.

5. **Deploy** to a public HTTPS endpoint (Railway, Render, AWS Lambda, etc.) and register the URL in the Meta Dashboard.

---

## File Structure

```
autostream-agent/
├── agent.py                    # LangGraph agent (nodes, edges, state)
├── tools.py                    # RAG retrieval + mock_lead_capture
├── main.py                     # CLI entrypoint
├── requirements.txt            # Python dependencies
├── README.md                   # This file
└── knowledge_base/
    └── autostream_kb.json      # Local knowledge base (pricing, policies, FAQs)
```

---

## Evaluation Checklist

| Criterion | Implementation |
|---|---|
| Intent detection | `classify_intent` node uses Claude 3 Haiku to label each turn |
| RAG knowledge retrieval | `retrieve_knowledge()` in `tools.py` with keyword-based routing over local JSON |
| State management (5–6 turns) | `AgentState` TypedDict threaded through all LangGraph nodes |
| Tool calling (not premature) | `capture_lead` node only reached after all 3 fields are collected |
| Code clarity | Each concern is a separate file / node with docstrings |
| WhatsApp deployment | Webhook architecture described above |

---

*Built with ❤️ using Claude 3 Haiku, LangGraph, and Python.*
