"""
main.py – Interactive CLI for the AutoStream AI Agent
Run: python main.py
"""

import os
import sys

# ── Ensure API key is set ────────────────────────────────────────────────────
if not os.environ.get("ANTHROPIC_API_KEY"):
    print("❌  Please set the ANTHROPIC_API_KEY environment variable and try again.")
    sys.exit(1)

from agent import chat, reset

BANNER = """
╔══════════════════════════════════════════════════════╗
║          🎬  AutoStream AI Sales Assistant           ║
║     Powered by Claude 3 Haiku + LangGraph (RAG)     ║
╚══════════════════════════════════════════════════════╝
Type your message and press Enter.
Commands: 'quit' or 'exit' to stop | 'reset' to restart.
"""

def main():
    print(BANNER)
    while True:
        try:
            user_input = input("You: ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\nGoodbye! 👋")
            break

        if not user_input:
            continue

        if user_input.lower() in {"quit", "exit"}:
            print("Goodbye! 👋")
            break

        if user_input.lower() == "reset":
            reset()
            print("🔄  Conversation reset.\n")
            continue

        reply = chat(user_input)
        print(f"\nAutoStream: {reply}\n")


if __name__ == "__main__":
    main()
