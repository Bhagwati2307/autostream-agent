"""
agent.py – AutoStream Conversational AI Agent
Built with LangGraph + Claude 3 Haiku (via Anthropic API)

Graph nodes
-----------
  classify_intent  → detect: greeting | inquiry | high_intent
  retrieve_rag     → fetch relevant knowledge for inquiry/high_intent
  generate_reply   → craft the assistant's response
  collect_lead     → gather name / email / platform one field at a time
  capture_lead     → call mock_lead_capture once all fields are present
"""

import os
import re
from typing import Annotated, Literal

from anthropic import Anthropic
from langgraph.graph import StateGraph, END
from langgraph.graph.message import add_messages
from typing_extensions import TypedDict

from tools import mock_lead_capture, retrieve_knowledge

# ── Anthropic client ─────────────────────────────────────────────────────────
_client = Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
_MODEL  = "claude-haiku-4-5-20251001"          # as required by the brief


# ── Agent state ──────────────────────────────────────────────────────────────
class AgentState(TypedDict):
    # Full conversation history (user + assistant turns)
    messages: Annotated[list[dict], add_messages]

    # Classified intent for the latest user turn
    intent: Literal["greeting", "inquiry", "high_intent", "unknown"]

    # RAG snippet surfaced for this turn
    retrieved_context: str

    # Lead collection fields
    lead_name:     str
    lead_email:    str
    lead_platform: str

    # Whether lead has been fully captured
    lead_captured: bool


def _initial_state() -> AgentState:
    return AgentState(
        messages=[],
        intent="unknown",
        retrieved_context="",
        lead_name="",
        lead_email="",
        lead_platform="",
        lead_captured=False,
    )


# ── System prompt ────────────────────────────────────────────────────────────
_SYSTEM = """You are AutoStream's friendly sales assistant.
AutoStream is a SaaS platform offering automated video-editing tools for content creators.

Your goals:
1. Greet users warmly.
2. Answer product and pricing questions accurately using ONLY the provided context.
3. When a user expresses genuine interest (high intent), collect their name, email, and
   creator platform (YouTube, Instagram, TikTok, etc.) – ONE field per turn, politely.
4. Confirm before finalising – never assume.
5. Keep replies concise (≤ 120 words) unless detail is explicitly asked for.
6. Never invent features, prices, or policies not in the context."""


# ============================================================
# Node 1 – Intent classifier
# ============================================================
def classify_intent(state: AgentState) -> AgentState:
    """Use Claude to classify the latest user message intent."""
    last_user = next(
        (m["content"] for m in reversed(state["messages"]) if m["role"] == "user"),
        "",
    )

    resp = _client.messages.create(
        model=_MODEL,
        max_tokens=50,
        system=(
            "Classify the user message into exactly ONE of these labels:\n"
            "  greeting       – simple hello / hi / how are you\n"
            "  inquiry        – asking about product, pricing, features, policies\n"
            "  high_intent    – explicitly wants to sign up, start trial, buy, or get started\n"
            "  unknown        – anything else\n\n"
            "Reply with ONLY the label, nothing else."
        ),
        messages=[{"role": "user", "content": last_user}],
    )
    label = resp.content[0].text.strip().lower()
    if label not in {"greeting", "inquiry", "high_intent", "unknown"}:
        label = "unknown"

    return {**state, "intent": label}


# ============================================================
# Node 2 – RAG retrieval
# ============================================================
def retrieve_rag(state: AgentState) -> AgentState:
    """Retrieve relevant knowledge base content."""
    last_user = next(
        (m["content"] for m in reversed(state["messages"]) if m["role"] == "user"),
        "",
    )
    context = retrieve_knowledge(last_user)
    return {**state, "retrieved_context": context}


# ============================================================
# Node 3 – Generate reply (greeting / inquiry / unknown)
# ============================================================
def generate_reply(state: AgentState) -> AgentState:
    """Generate a conversational reply using retrieved context."""
    system = _SYSTEM
    if state["retrieved_context"]:
        system += f"\n\n### Relevant knowledge base content\n{state['retrieved_context']}"

    resp = _client.messages.create(
        model=_MODEL,
        max_tokens=300,
        system=system,
        messages=state["messages"],
    )
    reply = resp.content[0].text.strip()
    new_messages = state["messages"] + [{"role": "assistant", "content": reply}]
    return {**state, "messages": new_messages, "retrieved_context": ""}


# ============================================================
# Node 4 – Collect lead fields (one per turn)
# ============================================================
def collect_lead(state: AgentState) -> AgentState:
    """Ask for whichever lead field is missing next."""
    name     = state["lead_name"]
    email    = state["lead_email"]
    platform = state["lead_platform"]

    # ── Extract from the latest user message ─────────────────────────────
    last_user = next(
        (m["content"] for m in reversed(state["messages"]) if m["role"] == "user"),
        "",
    )

    # We ask Claude to extract any of the three fields from the latest reply
    extract_prompt = (
        "Extract the following from the user message if present. "
        "Return ONLY a JSON object with keys name, email, platform "
        "(use empty string \"\" if not present):\n\n"
        f"Message: {last_user}"
    )
    ext = _client.messages.create(
        model=_MODEL,
        max_tokens=100,
        system="You extract structured data. Return ONLY valid JSON, no markdown.",
        messages=[{"role": "user", "content": extract_prompt}],
    )
    try:
        import json
        extracted = json.loads(ext.content[0].text.strip())
        if not name     and extracted.get("name"):     name     = extracted["name"]
        if not email    and extracted.get("email"):    email    = extracted["email"]
        if not platform and extracted.get("platform"): platform = extracted["platform"]
    except Exception:
        pass  # extraction failed – ask again next turn

    # ── Decide what to ask next ──────────────────────────────────────────
    if not name:
        question = "Great! I'd love to get you set up. Could you share your **full name**?"
    elif not email:
        question = f"Thanks, {name}! What's the best **email address** to reach you?"
    elif not platform:
        question = (
            f"Almost there! Which creator platform do you primarily use? "
            "(e.g. YouTube, Instagram, TikTok, Facebook…)"
        )
    else:
        # All collected – route to capture
        new_messages = state["messages"]
        return {
            **state,
            "messages": new_messages,
            "lead_name": name,
            "lead_email": email,
            "lead_platform": platform,
        }

    new_messages = state["messages"] + [{"role": "assistant", "content": question}]
    return {
        **state,
        "messages": new_messages,
        "lead_name": name,
        "lead_email": email,
        "lead_platform": platform,
    }


# ============================================================
# Node 5 – Execute lead capture tool
# ============================================================
def capture_lead(state: AgentState) -> AgentState:
    """Call mock_lead_capture and confirm to the user."""
    result = mock_lead_capture(
        name=state["lead_name"],
        email=state["lead_email"],
        platform=state["lead_platform"],
    )
    confirmation = (
        f"{result}\n\n"
        "Meanwhile, feel free to start your **7-day free trial** at autostream.io. "
        "No credit card required! 🎬"
    )
    new_messages = state["messages"] + [{"role": "assistant", "content": confirmation}]
    return {**state, "messages": new_messages, "lead_captured": True}


# ============================================================
# Routing logic
# ============================================================
def route_after_classify(state: AgentState) -> str:
    if state["lead_captured"]:
        return "generate_reply"   # post-capture small-talk
    intent = state["intent"]
    if intent in ("inquiry", "high_intent"):
        return "retrieve_rag"
    return "generate_reply"       # greeting / unknown


def route_after_rag(state: AgentState) -> str:
    if state["intent"] == "high_intent":
        return "collect_lead"
    return "generate_reply"


def route_after_collect(state: AgentState) -> str:
    """If all three fields present, capture; else stay in collect loop."""
    if state["lead_name"] and state["lead_email"] and state["lead_platform"]:
        return "capture_lead"
    return END   # wait for next user turn


# ============================================================
# Build the LangGraph
# ============================================================
def build_graph() -> StateGraph:
    g = StateGraph(AgentState)

    g.add_node("classify_intent", classify_intent)
    g.add_node("retrieve_rag",    retrieve_rag)
    g.add_node("generate_reply",  generate_reply)
    g.add_node("collect_lead",    collect_lead)
    g.add_node("capture_lead",    capture_lead)

    g.set_entry_point("classify_intent")

    g.add_conditional_edges("classify_intent", route_after_classify, {
        "retrieve_rag":   "retrieve_rag",
        "generate_reply": "generate_reply",
    })
    g.add_conditional_edges("retrieve_rag", route_after_rag, {
        "collect_lead":  "collect_lead",
        "generate_reply":"generate_reply",
    })
    g.add_conditional_edges("collect_lead", route_after_collect, {
        "capture_lead": "capture_lead",
        END: END,
    })

    g.add_edge("generate_reply", END)
    g.add_edge("capture_lead",   END)

    return g.compile()


# ============================================================
# Public API
# ============================================================
_graph = build_graph()
_state: AgentState = _initial_state()


def chat(user_message: str) -> str:
    """
    Send a message and return the agent's reply.
    Maintains conversation state across calls.
    """
    global _state
    _state = {**_state, "messages": _state["messages"] + [{"role": "user", "content": user_message}]}
    _state = _graph.invoke(_state)

    # Return the last assistant message
    for msg in reversed(_state["messages"]):
        if msg["role"] == "assistant":
            return msg["content"]
    return "(no reply)"


def reset():
    """Reset the agent state (start fresh conversation)."""
    global _state
    _state = _initial_state()
