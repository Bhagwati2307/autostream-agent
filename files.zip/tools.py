"""
tools.py – Tool definitions for the AutoStream agent.
Includes:
  - mock_lead_capture: simulates saving a lead to a CRM
  - retrieve_knowledge: simple RAG over the local JSON knowledge base
"""

import json
import os
from pathlib import Path

# ── Knowledge-base path ──────────────────────────────────────────────────────
_KB_PATH = Path(__file__).parent / "knowledge_base" / "autostream_kb.json"

with open(_KB_PATH, "r") as f:
    _KB: dict = json.load(f)


# ── Tool 1: RAG knowledge retrieval ─────────────────────────────────────────

def retrieve_knowledge(query: str) -> str:
    """
    Retrieve relevant knowledge from the AutoStream knowledge base.

    This is a lightweight keyword-based RAG implementation.
    In production you would embed chunks and do vector similarity search.

    Args:
        query: The user's question or topic.

    Returns:
        A formatted string with the most relevant knowledge-base content.
    """
    query_lower = query.lower()
    sections: list[str] = []

    # ── Pricing ──────────────────────────────────────────────────────────────
    pricing_keywords = {"price", "pricing", "cost", "plan", "plans", "basic",
                        "pro", "month", "monthly", "pay", "subscription",
                        "how much", "fee", "cheap", "expensive", "afford"}
    if pricing_keywords & set(query_lower.split()):
        p = _KB["pricing"]
        basic = p["basic"]
        pro   = p["pro"]
        sections.append(
            f"## AutoStream Pricing\n\n"
            f"**Basic Plan – ${basic['price_monthly']}/month**\n"
            + "\n".join(f"  - {f}" for f in basic["features"])
            + f"\n\n**Pro Plan – ${pro['price_monthly']}/month**\n"
            + "\n".join(f"  - {f}" for f in pro["features"])
        )

    # ── Policies ─────────────────────────────────────────────────────────────
    policy_keywords = {"refund", "cancel", "policy", "return", "money",
                       "support", "help", "trial", "free"}
    if policy_keywords & set(query_lower.split()):
        pol = _KB["policies"]
        sections.append(
            f"## AutoStream Policies\n\n"
            f"- **Refund Policy:** {pol['refund']}\n"
            f"- **Support:** {pol['support']}\n"
            f"- **Free Trial:** {pol['trial']}"
        )

    # ── Company / general ────────────────────────────────────────────────────
    general_keywords = {"autostream", "what", "about", "product", "service",
                        "does", "features", "platform", "tool", "edit",
                        "video", "creator", "youtube", "instagram", "tiktok"}
    if general_keywords & set(query_lower.split()):
        comp = _KB["company"]
        sections.append(f"## About AutoStream\n\n{comp['description']}")

    # ── FAQs ─────────────────────────────────────────────────────────────────
    for item in _KB["faq"]:
        if any(kw in query_lower for kw in item["question"].lower().split()):
            sections.append(f"**Q: {item['question']}**\nA: {item['answer']}")

    if not sections:
        # Fallback – return full pricing + company blurb
        sections.append(_KB["company"]["description"])
        sections.append(
            f"Basic Plan: ${_KB['pricing']['basic']['price_monthly']}/month | "
            f"Pro Plan: ${_KB['pricing']['pro']['price_monthly']}/month"
        )

    return "\n\n".join(sections)


# ── Tool 2: Mock lead capture ────────────────────────────────────────────────

def mock_lead_capture(name: str, email: str, platform: str) -> str:
    """
    Simulate saving a qualified lead to the CRM.

    Args:
        name:     Lead's full name.
        email:    Lead's email address.
        platform: Content platform (YouTube, Instagram, TikTok, etc.).

    Returns:
        A success message string.
    """
    # Basic validation
    if not name or not email or not platform:
        return "Error: All three fields (name, email, platform) are required."

    if "@" not in email or "." not in email.split("@")[-1]:
        return f"Error: '{email}' does not look like a valid email address."

    print(f"\n✅  Lead captured successfully: {name}, {email}, {platform}\n")

    return (
        f"✅ Lead captured successfully!\n"
        f"  • Name:     {name}\n"
        f"  • Email:    {email}\n"
        f"  • Platform: {platform}\n\n"
        "Our team will reach out within 24 hours. Thank you for your interest in AutoStream Pro!"
    )
